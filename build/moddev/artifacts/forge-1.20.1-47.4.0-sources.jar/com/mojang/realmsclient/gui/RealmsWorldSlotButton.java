package com.mojang.realmsclient.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.datafixers.util.Pair;
import com.mojang.realmsclient.dto.RealmsServer;
import com.mojang.realmsclient.dto.RealmsWorldOptions;
import com.mojang.realmsclient.util.RealmsTextureManager;
import java.util.function.Consumer;
import java.util.function.Supplier;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class RealmsWorldSlotButton extends Button {
   public static final ResourceLocation SLOT_FRAME_LOCATION = new ResourceLocation("realms", "textures/gui/realms/slot_frame.png");
   public static final ResourceLocation EMPTY_SLOT_LOCATION = new ResourceLocation("realms", "textures/gui/realms/empty_frame.png");
   public static final ResourceLocation CHECK_MARK_LOCATION = new ResourceLocation("minecraft", "textures/gui/checkmark.png");
   public static final ResourceLocation DEFAULT_WORLD_SLOT_1 = new ResourceLocation("minecraft", "textures/gui/title/background/panorama_0.png");
   public static final ResourceLocation DEFAULT_WORLD_SLOT_2 = new ResourceLocation("minecraft", "textures/gui/title/background/panorama_2.png");
   public static final ResourceLocation DEFAULT_WORLD_SLOT_3 = new ResourceLocation("minecraft", "textures/gui/title/background/panorama_3.png");
   private static final Component SLOT_ACTIVE_TOOLTIP = Component.translatable("mco.configure.world.slot.tooltip.active");
   private static final Component SWITCH_TO_MINIGAME_SLOT_TOOLTIP = Component.translatable("mco.configure.world.slot.tooltip.minigame");
   private static final Component SWITCH_TO_WORLD_SLOT_TOOLTIP = Component.translatable("mco.configure.world.slot.tooltip");
   private static final Component MINIGAME = Component.translatable("mco.worldSlot.minigame");
   private final Supplier<RealmsServer> serverDataProvider;
   private final Consumer<Component> toolTipSetter;
   private final int slotIndex;
   @Nullable
   private RealmsWorldSlotButton.State state;

   public RealmsWorldSlotButton(int x, int y, int width, int height, Supplier<RealmsServer> serverDataProvider, Consumer<Component> toolTipSetter, int slotIndex, Button.OnPress onPress) {
      super(x, y, width, height, CommonComponents.EMPTY, onPress, DEFAULT_NARRATION);
      this.serverDataProvider = serverDataProvider;
      this.slotIndex = slotIndex;
      this.toolTipSetter = toolTipSetter;
   }

   @Nullable
   public RealmsWorldSlotButton.State getState() {
      return this.state;
   }

   public void tick() {
      RealmsServer realmsserver = this.serverDataProvider.get();
      if (realmsserver != null) {
         RealmsWorldOptions realmsworldoptions = realmsserver.slots.get(this.slotIndex);
         boolean flag2 = this.slotIndex == 4;
         boolean flag;
         String s;
         long i;
         String s1;
         boolean flag1;
         if (flag2) {
            flag = realmsserver.worldType == RealmsServer.WorldType.MINIGAME;
            s = MINIGAME.getString();
            i = (long)realmsserver.minigameId;
            s1 = realmsserver.minigameImage;
            flag1 = realmsserver.minigameId == -1;
         } else {
            flag = realmsserver.activeSlot == this.slotIndex && realmsserver.worldType != RealmsServer.WorldType.MINIGAME;
            s = realmsworldoptions.getSlotName(this.slotIndex);
            i = realmsworldoptions.templateId;
            s1 = realmsworldoptions.templateImage;
            flag1 = realmsworldoptions.empty;
         }

         RealmsWorldSlotButton.Action realmsworldslotbutton$action = getAction(realmsserver, flag, flag2);
         Pair<Component, Component> pair = this.getTooltipAndNarration(realmsserver, s, flag1, flag2, realmsworldslotbutton$action);
         this.state = new RealmsWorldSlotButton.State(flag, s, i, s1, flag1, flag2, realmsworldslotbutton$action, pair.getFirst());
         this.setMessage(pair.getSecond());
      }
   }

   private static RealmsWorldSlotButton.Action getAction(RealmsServer realmsServer, boolean isCurrentlyActiveSlot, boolean minigame) {
      if (isCurrentlyActiveSlot) {
         if (!realmsServer.expired && realmsServer.state != RealmsServer.State.UNINITIALIZED) {
            return RealmsWorldSlotButton.Action.JOIN;
         }
      } else {
         if (!minigame) {
            return RealmsWorldSlotButton.Action.SWITCH_SLOT;
         }

         if (!realmsServer.expired) {
            return RealmsWorldSlotButton.Action.SWITCH_SLOT;
         }
      }

      return RealmsWorldSlotButton.Action.NOTHING;
   }

   private Pair<Component, Component> getTooltipAndNarration(RealmsServer realmsServer, String slotName, boolean empty, boolean minigame, RealmsWorldSlotButton.Action action) {
      if (action == RealmsWorldSlotButton.Action.NOTHING) {
         return Pair.of((Component)null, Component.literal(slotName));
      } else {
         Component component;
         if (minigame) {
            if (empty) {
               component = CommonComponents.EMPTY;
            } else {
               component = CommonComponents.space().append(slotName).append(CommonComponents.SPACE).append(realmsServer.minigameName);
            }
         } else {
            component = CommonComponents.space().append(slotName);
         }

         Component component1;
         if (action == RealmsWorldSlotButton.Action.JOIN) {
            component1 = SLOT_ACTIVE_TOOLTIP;
         } else {
            component1 = minigame ? SWITCH_TO_MINIGAME_SLOT_TOOLTIP : SWITCH_TO_WORLD_SLOT_TOOLTIP;
         }

         Component component2 = component1.copy().append(component);
         return Pair.of(component1, component2);
      }
   }

   public void renderWidget(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
      if (this.state != null) {
         this.drawSlotFrame(guiGraphics, this.getX(), this.getY(), mouseX, mouseY, this.state.isCurrentlyActiveSlot, this.state.slotName, this.slotIndex, this.state.imageId, this.state.image, this.state.empty, this.state.minigame, this.state.action, this.state.actionPrompt);
      }
   }

   private void drawSlotFrame(GuiGraphics guiGraphics, int x, int y, int mouseX, int mouseY, boolean isSelected, String text, int slotIndex, long imageId, @Nullable String image, boolean empty, boolean minigame, RealmsWorldSlotButton.Action action, @Nullable Component tooltip) {
      boolean flag = this.isHoveredOrFocused();
      if (this.isMouseOver((double)mouseX, (double)mouseY) && tooltip != null) {
         this.toolTipSetter.accept(tooltip);
      }

      Minecraft minecraft = Minecraft.getInstance();
      ResourceLocation resourcelocation;
      if (minigame) {
         resourcelocation = RealmsTextureManager.worldTemplate(String.valueOf(imageId), image);
      } else if (empty) {
         resourcelocation = EMPTY_SLOT_LOCATION;
      } else if (image != null && imageId != -1L) {
         resourcelocation = RealmsTextureManager.worldTemplate(String.valueOf(imageId), image);
      } else if (slotIndex == 1) {
         resourcelocation = DEFAULT_WORLD_SLOT_1;
      } else if (slotIndex == 2) {
         resourcelocation = DEFAULT_WORLD_SLOT_2;
      } else if (slotIndex == 3) {
         resourcelocation = DEFAULT_WORLD_SLOT_3;
      } else {
         resourcelocation = EMPTY_SLOT_LOCATION;
      }

      if (isSelected) {
         guiGraphics.setColor(0.56F, 0.56F, 0.56F, 1.0F);
      }

      guiGraphics.blit(resourcelocation, x + 3, y + 3, 0.0F, 0.0F, 74, 74, 74, 74);
      boolean flag1 = flag && action != RealmsWorldSlotButton.Action.NOTHING;
      if (flag1) {
         guiGraphics.setColor(1.0F, 1.0F, 1.0F, 1.0F);
      } else if (isSelected) {
         guiGraphics.setColor(0.8F, 0.8F, 0.8F, 1.0F);
      } else {
         guiGraphics.setColor(0.56F, 0.56F, 0.56F, 1.0F);
      }

      guiGraphics.blit(SLOT_FRAME_LOCATION, x, y, 0.0F, 0.0F, 80, 80, 80, 80);
      guiGraphics.setColor(1.0F, 1.0F, 1.0F, 1.0F);
      if (isSelected) {
         this.renderCheckMark(guiGraphics, x, y);
      }

      guiGraphics.drawCenteredString(minecraft.font, text, x + 40, y + 66, 16777215);
   }

   private void renderCheckMark(GuiGraphics guiGraphics, int x, int y) {
      RenderSystem.enableBlend();
      guiGraphics.blit(CHECK_MARK_LOCATION, x + 67, y + 4, 0.0F, 0.0F, 9, 8, 9, 8);
      RenderSystem.disableBlend();
   }

   @OnlyIn(Dist.CLIENT)
   public static enum Action {
      NOTHING,
      SWITCH_SLOT,
      JOIN;
   }

   @OnlyIn(Dist.CLIENT)
   public static class State {
      final boolean isCurrentlyActiveSlot;
      final String slotName;
      final long imageId;
      @Nullable
      final String image;
      public final boolean empty;
      public final boolean minigame;
      public final RealmsWorldSlotButton.Action action;
      @Nullable
      final Component actionPrompt;

      State(boolean isCurrentlyActiveSlot, String slotName, long imageId, @Nullable String image, boolean empty, boolean minigame, RealmsWorldSlotButton.Action action, @Nullable Component actionPrompt) {
         this.isCurrentlyActiveSlot = isCurrentlyActiveSlot;
         this.slotName = slotName;
         this.imageId = imageId;
         this.image = image;
         this.empty = empty;
         this.minigame = minigame;
         this.action = action;
         this.actionPrompt = actionPrompt;
      }
   }
}
