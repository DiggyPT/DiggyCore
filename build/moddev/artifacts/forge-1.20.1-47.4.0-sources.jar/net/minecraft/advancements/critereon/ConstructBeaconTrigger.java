package net.minecraft.advancements.critereon;

import com.google.gson.JsonObject;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;

public class ConstructBeaconTrigger extends SimpleCriterionTrigger<ConstructBeaconTrigger.TriggerInstance> {
   static final ResourceLocation ID = new ResourceLocation("construct_beacon");

   public ResourceLocation getId() {
      return ID;
   }

   public ConstructBeaconTrigger.TriggerInstance createInstance(JsonObject json, ContextAwarePredicate predicate, DeserializationContext deserializationContext) {
      MinMaxBounds.Ints minmaxbounds$ints = MinMaxBounds.Ints.fromJson(json.get("level"));
      return new ConstructBeaconTrigger.TriggerInstance(predicate, minmaxbounds$ints);
   }

   public void trigger(ServerPlayer player, int level) {
      this.trigger(player, (p_148028_) -> {
         return p_148028_.matches(level);
      });
   }

   public static class TriggerInstance extends AbstractCriterionTriggerInstance {
      private final MinMaxBounds.Ints level;

      public TriggerInstance(ContextAwarePredicate player, MinMaxBounds.Ints level) {
         super(ConstructBeaconTrigger.ID, player);
         this.level = level;
      }

      public static ConstructBeaconTrigger.TriggerInstance constructedBeacon() {
         return new ConstructBeaconTrigger.TriggerInstance(ContextAwarePredicate.ANY, MinMaxBounds.Ints.ANY);
      }

      public static ConstructBeaconTrigger.TriggerInstance constructedBeacon(MinMaxBounds.Ints level) {
         return new ConstructBeaconTrigger.TriggerInstance(ContextAwarePredicate.ANY, level);
      }

      public boolean matches(int level) {
         return this.level.matches(level);
      }

      public JsonObject serializeToJson(SerializationContext conditions) {
         JsonObject jsonobject = super.serializeToJson(conditions);
         jsonobject.add("level", this.level.serializeToJson());
         return jsonobject;
      }
   }
}
