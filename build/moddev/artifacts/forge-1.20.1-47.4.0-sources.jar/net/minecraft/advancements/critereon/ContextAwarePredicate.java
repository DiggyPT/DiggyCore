package net.minecraft.advancements.critereon;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import java.util.function.Predicate;
import javax.annotation.Nullable;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.parameters.LootContextParamSet;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.minecraft.world.level.storage.loot.predicates.LootItemConditions;

public class ContextAwarePredicate {
   public static final ContextAwarePredicate ANY = new ContextAwarePredicate(new LootItemCondition[0]);
   private final LootItemCondition[] conditions;
   private final Predicate<LootContext> compositePredicates;

   ContextAwarePredicate(LootItemCondition[] conditons) {
      this.conditions = conditons;
      this.compositePredicates = LootItemConditions.andConditions(conditons);
   }

   public static ContextAwarePredicate create(LootItemCondition... conditions) {
      return new ContextAwarePredicate(conditions);
   }

   @Nullable
   public static ContextAwarePredicate fromElement(String id, DeserializationContext context, @Nullable JsonElement element, LootContextParamSet paramSet) {
      if (element != null && element.isJsonArray()) {
         LootItemCondition[] alootitemcondition = context.deserializeConditions(element.getAsJsonArray(), context.getAdvancementId() + "/" + id, paramSet);
         return new ContextAwarePredicate(alootitemcondition);
      } else {
         return null;
      }
   }

   public boolean matches(LootContext context) {
      return this.compositePredicates.test(context);
   }

   public JsonElement toJson(SerializationContext context) {
      return (JsonElement)(this.conditions.length == 0 ? JsonNull.INSTANCE : context.serializeConditions(this.conditions));
   }

   public static JsonElement toJson(ContextAwarePredicate[] predicates, SerializationContext context) {
      if (predicates.length == 0) {
         return JsonNull.INSTANCE;
      } else {
         JsonArray jsonarray = new JsonArray();

         for(ContextAwarePredicate contextawarepredicate : predicates) {
            jsonarray.add(contextawarepredicate.toJson(context));
         }

         return jsonarray;
      }
   }
}
