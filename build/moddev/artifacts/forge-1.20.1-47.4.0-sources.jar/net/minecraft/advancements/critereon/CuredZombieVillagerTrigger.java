package net.minecraft.advancements.critereon;

import com.google.gson.JsonObject;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.level.storage.loot.LootContext;

public class CuredZombieVillagerTrigger extends SimpleCriterionTrigger<CuredZombieVillagerTrigger.TriggerInstance> {
   static final ResourceLocation ID = new ResourceLocation("cured_zombie_villager");

   public ResourceLocation getId() {
      return ID;
   }

   public CuredZombieVillagerTrigger.TriggerInstance createInstance(JsonObject json, ContextAwarePredicate predicate, DeserializationContext deserializationContext) {
      ContextAwarePredicate contextawarepredicate = EntityPredicate.fromJson(json, "zombie", deserializationContext);
      ContextAwarePredicate contextawarepredicate1 = EntityPredicate.fromJson(json, "villager", deserializationContext);
      return new CuredZombieVillagerTrigger.TriggerInstance(predicate, contextawarepredicate, contextawarepredicate1);
   }

   public void trigger(ServerPlayer player, Zombie zombie, Villager villager) {
      LootContext lootcontext = EntityPredicate.createContext(player, zombie);
      LootContext lootcontext1 = EntityPredicate.createContext(player, villager);
      this.trigger(player, (p_24285_) -> {
         return p_24285_.matches(lootcontext, lootcontext1);
      });
   }

   public static class TriggerInstance extends AbstractCriterionTriggerInstance {
      private final ContextAwarePredicate zombie;
      private final ContextAwarePredicate villager;

      public TriggerInstance(ContextAwarePredicate player, ContextAwarePredicate zombie, ContextAwarePredicate villager) {
         super(CuredZombieVillagerTrigger.ID, player);
         this.zombie = zombie;
         this.villager = villager;
      }

      public static CuredZombieVillagerTrigger.TriggerInstance curedZombieVillager() {
         return new CuredZombieVillagerTrigger.TriggerInstance(ContextAwarePredicate.ANY, ContextAwarePredicate.ANY, ContextAwarePredicate.ANY);
      }

      public boolean matches(LootContext zombie, LootContext villager) {
         if (!this.zombie.matches(zombie)) {
            return false;
         } else {
            return this.villager.matches(villager);
         }
      }

      public JsonObject serializeToJson(SerializationContext conditions) {
         JsonObject jsonobject = super.serializeToJson(conditions);
         jsonobject.add("zombie", this.zombie.toJson(conditions));
         jsonobject.add("villager", this.villager.toJson(conditions));
         return jsonobject;
      }
   }
}
