package net.minecraft.advancements.critereon;

import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Supplier;
import javax.annotation.Nullable;
import net.minecraft.network.chat.Component;
import net.minecraft.util.GsonHelper;

public abstract class MinMaxBounds<T extends Number> {
   public static final SimpleCommandExceptionType ERROR_EMPTY = new SimpleCommandExceptionType(Component.translatable("argument.range.empty"));
   public static final SimpleCommandExceptionType ERROR_SWAPPED = new SimpleCommandExceptionType(Component.translatable("argument.range.swapped"));
   @Nullable
   protected final T min;
   @Nullable
   protected final T max;

   protected MinMaxBounds(@Nullable T min, @Nullable T max) {
      this.min = min;
      this.max = max;
   }

   @Nullable
   public T getMin() {
      return this.min;
   }

   @Nullable
   public T getMax() {
      return this.max;
   }

   public boolean isAny() {
      return this.min == null && this.max == null;
   }

   public JsonElement serializeToJson() {
      if (this.isAny()) {
         return JsonNull.INSTANCE;
      } else if (this.min != null && this.min.equals(this.max)) {
         return new JsonPrimitive(this.min);
      } else {
         JsonObject jsonobject = new JsonObject();
         if (this.min != null) {
            jsonobject.addProperty("min", this.min);
         }

         if (this.max != null) {
            jsonobject.addProperty("max", this.max);
         }

         return jsonobject;
      }
   }

   protected static <T extends Number, R extends MinMaxBounds<T>> R fromJson(@Nullable JsonElement json, R defaultValue, BiFunction<JsonElement, String, T> valueFactory, MinMaxBounds.BoundsFactory<T, R> boundedFactory) {
      if (json != null && !json.isJsonNull()) {
         if (GsonHelper.isNumberValue(json)) {
            T t2 = valueFactory.apply(json, "value");
            return boundedFactory.create(t2, t2);
         } else {
            JsonObject jsonobject = GsonHelper.convertToJsonObject(json, "value");
            T t = jsonobject.has("min") ? valueFactory.apply(jsonobject.get("min"), "min") : null;
            T t1 = jsonobject.has("max") ? valueFactory.apply(jsonobject.get("max"), "max") : null;
            return boundedFactory.create(t, t1);
         }
      } else {
         return defaultValue;
      }
   }

   protected static <T extends Number, R extends MinMaxBounds<T>> R fromReader(StringReader reader, MinMaxBounds.BoundsFromReaderFactory<T, R> boundedFactory, Function<String, T> valueFactory, Supplier<DynamicCommandExceptionType> commandExceptionSupplier, Function<T, T> formatter) throws CommandSyntaxException {
      if (!reader.canRead()) {
         throw ERROR_EMPTY.createWithContext(reader);
      } else {
         int i = reader.getCursor();

         try {
            T t = optionallyFormat(readNumber(reader, valueFactory, commandExceptionSupplier), formatter);
            T t1;
            if (reader.canRead(2) && reader.peek() == '.' && reader.peek(1) == '.') {
               reader.skip();
               reader.skip();
               t1 = optionallyFormat(readNumber(reader, valueFactory, commandExceptionSupplier), formatter);
               if (t == null && t1 == null) {
                  throw ERROR_EMPTY.createWithContext(reader);
               }
            } else {
               t1 = t;
            }

            if (t == null && t1 == null) {
               throw ERROR_EMPTY.createWithContext(reader);
            } else {
               return boundedFactory.create(reader, t, t1);
            }
         } catch (CommandSyntaxException commandsyntaxexception) {
            reader.setCursor(i);
            throw new CommandSyntaxException(commandsyntaxexception.getType(), commandsyntaxexception.getRawMessage(), commandsyntaxexception.getInput(), i);
         }
      }
   }

   @Nullable
   private static <T extends Number> T readNumber(StringReader reader, Function<String, T> stringToValueFunction, Supplier<DynamicCommandExceptionType> commandExceptionSupplier) throws CommandSyntaxException {
      int i = reader.getCursor();

      while(reader.canRead() && isAllowedInputChat(reader)) {
         reader.skip();
      }

      String s = reader.getString().substring(i, reader.getCursor());
      if (s.isEmpty()) {
         return (T)null;
      } else {
         try {
            return stringToValueFunction.apply(s);
         } catch (NumberFormatException numberformatexception) {
            throw commandExceptionSupplier.get().createWithContext(reader, s);
         }
      }
   }

   private static boolean isAllowedInputChat(StringReader reader) {
      char c0 = reader.peek();
      if ((c0 < '0' || c0 > '9') && c0 != '-') {
         if (c0 != '.') {
            return false;
         } else {
            return !reader.canRead(2) || reader.peek(1) != '.';
         }
      } else {
         return true;
      }
   }

   @Nullable
   private static <T> T optionallyFormat(@Nullable T value, Function<T, T> formatter) {
      return (T)(value == null ? null : formatter.apply(value));
   }

   @FunctionalInterface
   protected interface BoundsFactory<T extends Number, R extends MinMaxBounds<T>> {
      R create(@Nullable T min, @Nullable T max);
   }

   @FunctionalInterface
   protected interface BoundsFromReaderFactory<T extends Number, R extends MinMaxBounds<T>> {
      R create(StringReader reader, @Nullable T min, @Nullable T max) throws CommandSyntaxException;
   }

   public static class Doubles extends MinMaxBounds<Double> {
      public static final MinMaxBounds.Doubles ANY = new MinMaxBounds.Doubles((Double)null, (Double)null);
      @Nullable
      private final Double minSq;
      @Nullable
      private final Double maxSq;

      private static MinMaxBounds.Doubles create(StringReader reader, @Nullable Double min, @Nullable Double max) throws CommandSyntaxException {
         if (min != null && max != null && min > max) {
            throw ERROR_SWAPPED.createWithContext(reader);
         } else {
            return new MinMaxBounds.Doubles(min, max);
         }
      }

      @Nullable
      private static Double squareOpt(@Nullable Double value) {
         return value == null ? null : value * value;
      }

      private Doubles(@Nullable Double min, @Nullable Double max) {
         super(min, max);
         this.minSq = squareOpt(min);
         this.maxSq = squareOpt(max);
      }

      public static MinMaxBounds.Doubles exactly(double value) {
         return new MinMaxBounds.Doubles(value, value);
      }

      public static MinMaxBounds.Doubles between(double min, double max) {
         return new MinMaxBounds.Doubles(min, max);
      }

      public static MinMaxBounds.Doubles atLeast(double min) {
         return new MinMaxBounds.Doubles(min, (Double)null);
      }

      public static MinMaxBounds.Doubles atMost(double max) {
         return new MinMaxBounds.Doubles((Double)null, max);
      }

      public boolean matches(double value) {
         if (this.min != null && this.min > value) {
            return false;
         } else {
            return this.max == null || !(this.max < value);
         }
      }

      public boolean matchesSqr(double value) {
         if (this.minSq != null && this.minSq > value) {
            return false;
         } else {
            return this.maxSq == null || !(this.maxSq < value);
         }
      }

      public static MinMaxBounds.Doubles fromJson(@Nullable JsonElement json) {
         return fromJson(json, ANY, GsonHelper::convertToDouble, MinMaxBounds.Doubles::new);
      }

      public static MinMaxBounds.Doubles fromReader(StringReader reader) throws CommandSyntaxException {
         return fromReader(reader, (p_154807_) -> {
            return p_154807_;
         });
      }

      public static MinMaxBounds.Doubles fromReader(StringReader reader, Function<Double, Double> formatter) throws CommandSyntaxException {
         return fromReader(reader, MinMaxBounds.Doubles::create, Double::parseDouble, CommandSyntaxException.BUILT_IN_EXCEPTIONS::readerInvalidDouble, formatter);
      }
   }

   public static class Ints extends MinMaxBounds<Integer> {
      public static final MinMaxBounds.Ints ANY = new MinMaxBounds.Ints((Integer)null, (Integer)null);
      @Nullable
      private final Long minSq;
      @Nullable
      private final Long maxSq;

      private static MinMaxBounds.Ints create(StringReader reader, @Nullable Integer min, @Nullable Integer max) throws CommandSyntaxException {
         if (min != null && max != null && min > max) {
            throw ERROR_SWAPPED.createWithContext(reader);
         } else {
            return new MinMaxBounds.Ints(min, max);
         }
      }

      @Nullable
      private static Long squareOpt(@Nullable Integer value) {
         return value == null ? null : value.longValue() * value.longValue();
      }

      private Ints(@Nullable Integer min, @Nullable Integer max) {
         super(min, max);
         this.minSq = squareOpt(min);
         this.maxSq = squareOpt(max);
      }

      public static MinMaxBounds.Ints exactly(int value) {
         return new MinMaxBounds.Ints(value, value);
      }

      public static MinMaxBounds.Ints between(int min, int max) {
         return new MinMaxBounds.Ints(min, max);
      }

      public static MinMaxBounds.Ints atLeast(int min) {
         return new MinMaxBounds.Ints(min, (Integer)null);
      }

      public static MinMaxBounds.Ints atMost(int max) {
         return new MinMaxBounds.Ints((Integer)null, max);
      }

      public boolean matches(int value) {
         if (this.min != null && this.min > value) {
            return false;
         } else {
            return this.max == null || this.max >= value;
         }
      }

      public boolean matchesSqr(long value) {
         if (this.minSq != null && this.minSq > value) {
            return false;
         } else {
            return this.maxSq == null || this.maxSq >= value;
         }
      }

      public static MinMaxBounds.Ints fromJson(@Nullable JsonElement json) {
         return fromJson(json, ANY, GsonHelper::convertToInt, MinMaxBounds.Ints::new);
      }

      public static MinMaxBounds.Ints fromReader(StringReader reader) throws CommandSyntaxException {
         return fromReader(reader, (p_55389_) -> {
            return p_55389_;
         });
      }

      public static MinMaxBounds.Ints fromReader(StringReader reader, Function<Integer, Integer> valueFunction) throws CommandSyntaxException {
         return fromReader(reader, MinMaxBounds.Ints::create, Integer::parseInt, CommandSyntaxException.BUILT_IN_EXCEPTIONS::readerInvalidInt, valueFunction);
      }
   }
}
