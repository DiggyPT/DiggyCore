package net.minecraft.advancements.critereon;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.GsonHelper;
import net.minecraft.world.item.ItemStack;

public class RecipeCraftedTrigger extends SimpleCriterionTrigger<RecipeCraftedTrigger.TriggerInstance> {
   static final ResourceLocation ID = new ResourceLocation("recipe_crafted");

   public ResourceLocation getId() {
      return ID;
   }

   protected RecipeCraftedTrigger.TriggerInstance createInstance(JsonObject json, ContextAwarePredicate predicate, DeserializationContext deserializationContext) {
      ResourceLocation resourcelocation = new ResourceLocation(GsonHelper.getAsString(json, "recipe_id"));
      ItemPredicate[] aitempredicate = ItemPredicate.fromJsonArray(json.get("ingredients"));
      return new RecipeCraftedTrigger.TriggerInstance(predicate, resourcelocation, List.of(aitempredicate));
   }

   public void trigger(ServerPlayer player, ResourceLocation recipeId, List<ItemStack> items) {
      this.trigger(player, (p_282798_) -> {
         return p_282798_.matches(recipeId, items);
      });
   }

   public static class TriggerInstance extends AbstractCriterionTriggerInstance {
      private final ResourceLocation recipeId;
      private final List<ItemPredicate> predicates;

      public TriggerInstance(ContextAwarePredicate player, ResourceLocation recipeId, List<ItemPredicate> predicates) {
         super(RecipeCraftedTrigger.ID, player);
         this.recipeId = recipeId;
         this.predicates = predicates;
      }

      public static RecipeCraftedTrigger.TriggerInstance craftedItem(ResourceLocation recipeId, List<ItemPredicate> predicates) {
         return new RecipeCraftedTrigger.TriggerInstance(ContextAwarePredicate.ANY, recipeId, predicates);
      }

      public static RecipeCraftedTrigger.TriggerInstance craftedItem(ResourceLocation recipeId) {
         return new RecipeCraftedTrigger.TriggerInstance(ContextAwarePredicate.ANY, recipeId, List.of());
      }

      boolean matches(ResourceLocation recipeId, List<ItemStack> items) {
         if (!recipeId.equals(this.recipeId)) {
            return false;
         } else {
            List<ItemStack> list = new ArrayList<>(items);

            for(ItemPredicate itempredicate : this.predicates) {
               boolean flag = false;
               Iterator<ItemStack> iterator = list.iterator();

               while(iterator.hasNext()) {
                  if (itempredicate.matches(iterator.next())) {
                     iterator.remove();
                     flag = true;
                     break;
                  }
               }

               if (!flag) {
                  return false;
               }
            }

            return true;
         }
      }

      public JsonObject serializeToJson(SerializationContext conditions) {
         JsonObject jsonobject = super.serializeToJson(conditions);
         jsonobject.addProperty("recipe_id", this.recipeId.toString());
         if (this.predicates.size() > 0) {
            JsonArray jsonarray = new JsonArray();

            for(ItemPredicate itempredicate : this.predicates) {
               jsonarray.add(itempredicate.serializeToJson());
            }

            jsonobject.add("ingredients", jsonarray);
         }

         return jsonobject;
      }
   }
}
