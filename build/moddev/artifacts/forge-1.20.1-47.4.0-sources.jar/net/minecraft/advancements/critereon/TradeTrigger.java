package net.minecraft.advancements.critereon;

import com.google.gson.JsonObject;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.LootContext;

public class TradeTrigger extends SimpleCriterionTrigger<TradeTrigger.TriggerInstance> {
   static final ResourceLocation ID = new ResourceLocation("villager_trade");

   public ResourceLocation getId() {
      return ID;
   }

   public TradeTrigger.TriggerInstance createInstance(JsonObject json, ContextAwarePredicate predicate, DeserializationContext deserializationContext) {
      ContextAwarePredicate contextawarepredicate = EntityPredicate.fromJson(json, "villager", deserializationContext);
      ItemPredicate itempredicate = ItemPredicate.fromJson(json.get("item"));
      return new TradeTrigger.TriggerInstance(predicate, contextawarepredicate, itempredicate);
   }

   public void trigger(ServerPlayer player, AbstractVillager villager, ItemStack stack) {
      LootContext lootcontext = EntityPredicate.createContext(player, villager);
      this.trigger(player, (p_70970_) -> {
         return p_70970_.matches(lootcontext, stack);
      });
   }

   public static class TriggerInstance extends AbstractCriterionTriggerInstance {
      private final ContextAwarePredicate villager;
      private final ItemPredicate item;

      public TriggerInstance(ContextAwarePredicate player, ContextAwarePredicate villager, ItemPredicate item) {
         super(TradeTrigger.ID, player);
         this.villager = villager;
         this.item = item;
      }

      public static TradeTrigger.TriggerInstance tradedWithVillager() {
         return new TradeTrigger.TriggerInstance(ContextAwarePredicate.ANY, ContextAwarePredicate.ANY, ItemPredicate.ANY);
      }

      public static TradeTrigger.TriggerInstance tradedWithVillager(EntityPredicate.Builder villager) {
         return new TradeTrigger.TriggerInstance(EntityPredicate.wrap(villager.build()), ContextAwarePredicate.ANY, ItemPredicate.ANY);
      }

      public boolean matches(LootContext context, ItemStack stack) {
         if (!this.villager.matches(context)) {
            return false;
         } else {
            return this.item.matches(stack);
         }
      }

      public JsonObject serializeToJson(SerializationContext conditions) {
         JsonObject jsonobject = super.serializeToJson(conditions);
         jsonobject.add("item", this.item.serializeToJson());
         jsonobject.add("villager", this.villager.toJson(conditions));
         return jsonobject;
      }
   }
}
