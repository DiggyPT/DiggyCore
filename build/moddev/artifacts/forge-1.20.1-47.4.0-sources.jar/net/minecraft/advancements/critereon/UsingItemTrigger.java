package net.minecraft.advancements.critereon;

import com.google.gson.JsonObject;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;

public class UsingItemTrigger extends SimpleCriterionTrigger<UsingItemTrigger.TriggerInstance> {
   static final ResourceLocation ID = new ResourceLocation("using_item");

   public ResourceLocation getId() {
      return ID;
   }

   public UsingItemTrigger.TriggerInstance createInstance(JsonObject json, ContextAwarePredicate predicate, DeserializationContext deserializationContext) {
      ItemPredicate itempredicate = ItemPredicate.fromJson(json.get("item"));
      return new UsingItemTrigger.TriggerInstance(predicate, itempredicate);
   }

   public void trigger(ServerPlayer player, ItemStack item) {
      this.trigger(player, (p_163870_) -> {
         return p_163870_.matches(item);
      });
   }

   public static class TriggerInstance extends AbstractCriterionTriggerInstance {
      private final ItemPredicate item;

      public TriggerInstance(ContextAwarePredicate player, ItemPredicate item) {
         super(UsingItemTrigger.ID, player);
         this.item = item;
      }

      public static UsingItemTrigger.TriggerInstance lookingAt(EntityPredicate.Builder entityPredicateBuilder, ItemPredicate.Builder itemPredicateBuilder) {
         return new UsingItemTrigger.TriggerInstance(EntityPredicate.wrap(entityPredicateBuilder.build()), itemPredicateBuilder.build());
      }

      public boolean matches(ItemStack item) {
         return this.item.matches(item);
      }

      public JsonObject serializeToJson(SerializationContext conditions) {
         JsonObject jsonobject = super.serializeToJson(conditions);
         jsonobject.add("item", this.item.serializeToJson());
         return jsonobject;
      }
   }
}
