package net.minecraft.client.gui.components;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class StringWidget extends AbstractStringWidget {
   private float alignX = 0.5F;

   public StringWidget(Component message, Font font) {
      this(0, 0, font.width(message.getVisualOrderText()), 9, message, font);
   }

   public StringWidget(int width, int height, Component message, Font font) {
      this(0, 0, width, height, message, font);
   }

   public StringWidget(int x, int y, int width, int height, Component message, Font font) {
      super(x, y, width, height, message, font);
      this.active = false;
   }

   public StringWidget setColor(int color) {
      super.setColor(color);
      return this;
   }

   private StringWidget horizontalAlignment(float horizontalAlignment) {
      this.alignX = horizontalAlignment;
      return this;
   }

   public StringWidget alignLeft() {
      return this.horizontalAlignment(0.0F);
   }

   public StringWidget alignCenter() {
      return this.horizontalAlignment(0.5F);
   }

   public StringWidget alignRight() {
      return this.horizontalAlignment(1.0F);
   }

   public void renderWidget(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
      Component component = this.getMessage();
      Font font = this.getFont();
      int i = this.getX() + Math.round(this.alignX * (float)(this.getWidth() - font.width(component)));
      int j = this.getY() + (this.getHeight() - 9) / 2;
      guiGraphics.drawString(font, component, i, j, this.getColor());
   }
}
